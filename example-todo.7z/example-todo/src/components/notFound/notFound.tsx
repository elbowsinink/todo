const NotFound: React.FC = () => {
    return (
        <h1> Sorry! We can not find anything!!!</h1>
    )
}

export default NotFound;